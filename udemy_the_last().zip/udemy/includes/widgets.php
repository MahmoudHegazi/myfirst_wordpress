<?php
//here we create the widget area
// %1$s help the widgets to apply the id's and class
function ju_widgets() {
  register_sidebar([
    'name'             =>  __( 'My First theme sidebar', 'udemy' ),
    'id'               =>  'ju_sidebar',
    'description'      =>  __( 'Sidebar for the theme udemy', 'udemy' ),
    'before_widget'    =>  '<div id="%1$s" class="widget cleafix %2$s">',
    'after_widget'     =>  '</div>',
    'before_title'     =>  '<h4>',
    'after_title'      =>  '</h4>'
  ]);
}

?>
